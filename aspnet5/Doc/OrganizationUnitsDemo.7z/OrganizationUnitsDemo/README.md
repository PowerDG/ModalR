A sample project to demonstrate Organization Units usage.

See ProductManager class and it's test class (ProductManager_Tests) for use cases.

See documentation fore more: http://www.aspnetboilerplate.com/Pages/Documents/Zero/Organization-Units
