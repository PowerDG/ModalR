﻿namespace OrganizationUnitsDemo
{
    public class OrganizationUnitsDemoConsts
    {
        public const string LocalizationSourceName = "OrganizationUnitsDemo";
    }
}