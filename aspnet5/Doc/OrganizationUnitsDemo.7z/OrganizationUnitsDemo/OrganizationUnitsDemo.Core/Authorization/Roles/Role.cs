﻿using Abp.Authorization.Roles;
using OrganizationUnitsDemo.Users;

namespace OrganizationUnitsDemo.Authorization.Roles
{
    public class Role : AbpRole<User>
    {

    }
}