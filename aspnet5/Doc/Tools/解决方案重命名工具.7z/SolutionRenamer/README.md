# SolutionRenamer
Fast rename solution,using .net core 2.0

doc
==

- [快速重命名解决方案](http://www.cnblogs.com/stulzq/p/7505912.html "快速重命名解决方案")
